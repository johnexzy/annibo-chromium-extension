# Annibo
### Welcome 👋
This is the chromium extension for Annibo:  
Create Intuitive Contents, articles or blog using AI. https://annibo.up.railway.app/
